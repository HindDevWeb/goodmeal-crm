<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="relative chart-payment-modes" style="max-height:400px;">
	<canvas id="chart-payment-modes" class="animated fadeIn" height="400"></canvas>
</div>
