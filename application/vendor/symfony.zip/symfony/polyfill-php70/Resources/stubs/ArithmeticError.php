<?php

class ArithmeticError extends Error
{
}
