<?php

namespace Omnipay\AuthorizeNet\Message;

class CIMCaptureRequest extends AIMCaptureRequest
{
}
