<?php

namespace Omnipay\AuthorizeNet\Message;

/**
 * Authorize.Net CIM Void Request
 */
class CIMVoidRequest extends AIMVoidRequest
{
}
