<?php

namespace Omnipay\AuthorizeNet\Message;

/**
 * Creates a refund transaction request for the specified card, transaction
 */
class CIMRefundRequest extends AIMRefundRequest
{

}
