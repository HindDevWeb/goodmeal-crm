<?php

namespace Omnipay\AuthorizeNet\Message;

/**
 * Authorize.Net CIM transaction Response
 */
class CIMResponse extends CIMAbstractResponse
{
}
