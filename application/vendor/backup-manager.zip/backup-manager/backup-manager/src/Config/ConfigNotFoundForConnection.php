<?php namespace BackupManager\Config;

/**
 * Class ConfigNotFoundForConnection
 * @package BackupManager\Config
 */
class ConfigNotFoundForConnection extends \Exception {}
