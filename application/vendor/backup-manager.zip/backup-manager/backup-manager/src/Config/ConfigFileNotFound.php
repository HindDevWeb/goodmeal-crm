<?php namespace BackupManager\Config;

/**
 * Class ConfigFileNotFound
 * @package BackupManager\Config
 */
class ConfigFileNotFound extends \Exception {}
