<?php namespace BackupManager\Compressors;

/**
 * Class CompressorTypeNotSupported
 * @package BackupManager\Compressors
 */
class CompressorTypeNotSupported extends \Exception {}
