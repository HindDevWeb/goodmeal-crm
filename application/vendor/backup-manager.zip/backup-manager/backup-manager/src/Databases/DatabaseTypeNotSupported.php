<?php namespace BackupManager\Databases;

/**
 * Class DatabaseTypeNotSupported
 * @package BackupManager\Databases
 */
class DatabaseTypeNotSupported extends \Exception {}
